package ru.sash0k.bluetooth_terminal;

/**
 * Created by sash0k on 12.12.13.
 * Общие константы
 */
public class Const {
    static final String TAG = "SPP_TERMINAL";
}
